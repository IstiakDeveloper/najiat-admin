<div>
    <h1>Thank You!</h1>

    <p>Invoice Number: {{ $invoice->invoice_number }}</p>
    <p>Total Sale: {{ $invoice->total_sale }}</p>

    <!-- Add other invoice details you want to display -->

    <p>Emergency Contact: {{ $emergencyContact }}</p>
</div>
