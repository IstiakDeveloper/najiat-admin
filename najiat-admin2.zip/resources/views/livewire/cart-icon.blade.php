<div>
    <a href="{{ route('cart.index') }}">
        <i class="fas fa-shopping-cart mr-2"></i>
        <!-- Cart Count Badge -->
        <span class="bg-red-500 text-white rounded-full px-2 absolute top-0 right-0">{{ $cartCount }}</span>
        <span></span>
    </a>
</div>
