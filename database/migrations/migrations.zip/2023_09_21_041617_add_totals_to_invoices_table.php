<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddTotalsToInvoicesTable extends Migration
{
    public function up()
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->decimal('total_expense', 10, 2)->default(0);
            $table->decimal('total_sale', 10, 2)->default(0);
            $table->decimal('net_profit', 10, 2)->default(0);
        });
    }

    public function down()
    {
        Schema::table('invoices', function (Blueprint $table) {
            $table->dropColumn(['total_expense', 'total_sale', 'net_profit']);
        });
    }
}
